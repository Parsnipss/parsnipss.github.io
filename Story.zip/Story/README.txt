You need to install colorama for this to work!

open bash and type "pip install colorama"

You can then enjoy the story!